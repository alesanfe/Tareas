
import matplotlib.pyplot as plt
import numpy as np
from Tool import Covid as C


def Draw_Piechar(labels: list, sizes: list):
    """
    Función de Miguel Toro que dibuja una gráfica circular.
    """
    plt.pie(sizes, labels=labels)
    plt.axis('equal')
    plt.show()


def Draw_Barchart(labels: list, sizes: list, title: str='Diagramama de Barras', y_label: str='Eje Y', x_label: str='Eje X'):
    """
    Función de Miguel Toro que dibuja un diagrama de barras.
    """
    y_pos = np.arange(len(sizes))
    plt.bar(y_pos, sizes, align='center', alpha=0.5)
    plt.xticks(y_pos, labels)
    plt.ylabel(y_label)
    plt.xlabel(x_label)
    plt.title(title)
    plt.show()


def Draw_Multiline(points: list, y_label: str, x_label: str, title: str):
    """
    Función de Miguel Toro que dibuja una gráfica formada por la unión de puntos.
    """
    plt.ylabel(y_label)
    plt.xlabel(x_label)
    plt.title(title)
    plt.plot([x[0] for x in points], [x[1] for x in points])
    plt.show()


def Points(info: list) -> list:
    """
    Forma las coordenadas para la gráfica.
    """

    Lista1 = []
    for i in range(0, len(info)-1):
        puntos = (int(i+1), int(info[i]))
        Lista1.append(puntos)
    return Lista1


def Input_Zero(modificada: list, original: list, respuesta) -> list:
    """
    Añade ceros para poder tener todos los valores posibles.
    """
    if respuesta == "NO":
        comienzo = 0
        Lista1 = C.Show_Something(modificada, "state")
        Lista2 = C.Show_Something(modificada, "fips")
        final = len(Lista1)
    elif respuesta == "SI":
        comienzo = len(modificada)
        Lista1 = C.Show_Something(original, "state")
        Lista2 = C.Show_Something(original, "fips")
        final = len(Lista1)
    while len(modificada) <= final-1:
        for i in range(comienzo, final):
            if Lista1 not in modificada:
                tupla = ()
                tupla = (modificada[0][0], Lista1[i], Lista2[i], 0, 1)
                modificada.append(tupla)
    if respuesta == "NO":
        Lista3 = modificada
    elif respuesta == "SI":
        Lista3 = C.Order_States(modificada)
    return Lista3
