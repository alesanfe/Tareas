import time
import sys


#===============================================================================
# def Read(inicio: int, final: int, fichero: str):
#     """
#     Permite abrir fácilmente un fichero.
#     """
#     with open(fichero, encoding='utf-8') as f:
#         for num_linea, linea in enumerate(f):
#             if num_linea < inicio:
#                 continue
#             elif inicio <= num_linea <= final:
#                 print(linea, end='')
#             elif num_linea > final:
#                 break
#===============================================================================


#===============================================================================
# def Create_Text(fichero: str, mensaje: str):
#     """
#     Permite crear un archivo de texto que posteriormente será eliminado
#     """
#     Info = open(fichero, "w")
#     Info.write(mensaje)
#     Info.close()
#===============================================================================


def Change(número: int) -> int:
    """
    Permite cambiar de sección en el módulo ProgrProgram  """
    print("Continuar [1], cambiar  seccion [2] o bloque [3] o apagar [4].")
    respuesta = input("Introducir respuesta: ")
    if respuesta == "1":
        print("Entendido")
    elif respuesta == "2":
        número = 32
    elif respuesta == "3":
        número = 37
    elif respuesta == "4":
        número = 42
    return número


def Check_Number(mensaje: str, función) -> int:
    """
    Hace que si se necesita un número a continuación sea imposible introducir una letra o frase.
    """
    while True:
        try:
            número = función(input(mensaje))
            return número
            break
        except ValueError:
            print("Valor incorrecto.\n")


def Check_State(info: list) -> str:
    """
    Hace que la única posibilidad a introducir sea uno de los estados en el documento excel.
    """
    while True:
        estado = input("Introduzca un estado: ")
        for i in range(0, len(info)):
            if estado in info[i]:
                return estado
            elif estado not in info[i]:
                continue
        print("El estado introducido no está disponible.\n")


def Check_Date(info: list) -> str:
    """
    Hace que solo se pueda introducir una de las fechas disponibles en el documento excel.
    """
    while True:
        mes = input("Introduzca el mes: ")
        día = input("Introduzca el día: ")
        fecha = f"2020-{mes}-{día}"
        for i in range(0, len(info)):
            if fecha in info[i]:
                return mes, día
            elif fecha not in info[i]:
                continue
        print("La fecha es incorrecta.\n")


def Check_Yes_NO(mensaje: str) -> str:
    """
    Hace que solo podemos introducir si o no.
    """

    respuesta = input(mensaje).upper()
    while True:
        if respuesta == "SI" or respuesta == "NO":
            break
        else:
            print("\nRespuesta no válida.")
            respuesta = input("Introduzca SI o NO: ").upper()
    return respuesta


def Limit(mensaje: str, frontera: int, correcto: str) -> float:
    """ 
    Hace que solo sea posible introducir un número positivo en un intervalo especificado.
    """
    número = Check_Number(mensaje, int)
    while True:
        if correcto == "negativo":  # Si correcto = "Positivo", hace que únicamente se pueda acceder a un número comprendido entre uno mayor que cero y uno menor que la frontera.
            while True:
                if número < frontera:
                    return número
                    break
                elif número >= frontera or número <= 0:
                    print("No es posible.\n")
                    número = Check_Number(mensaje, int)
        else:
            break
    while True:
        if correcto == "positivo":  # Si correcto = "Positivo",hace que solo se puedan introducir números mayores al número frontera,
            while True:
                if número > frontera:
                    return número
                    break
                elif número <= frontera or número <= 0:
                    print("No es posible.\n")
                    número = Check_Number(mensaje, int)
        else:
            break


def Lines(nombre: str) -> str:
    """
    Tiene una función estética con el objetivo de dividir las diferentes secciones del módulo Program.
    """
    print()
    Slow(f"----------({nombre})----------")
    print("\n")


def Slow(frase) -> str:
    """
    Tiene una función estética con el objetivo de realentizar lo que aparece en pantalla en el módulo Program.
    """
    for x in frase:
        print(x, end='')
        sys.stdout.flush()
        time.sleep(0.075)  # Produce la parte del retardo.

