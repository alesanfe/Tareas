import os
from typing import TypeVar
from math import sqrt
from dataclasses import dataclass


def Binario_Decimal(binario):
    Máximo = len(binario)
    Decimal = 0
    Exponente = 0
    for i in range(Máximo-1, 0, -1):
        Decimal += int(binario[i])*2**Exponente
        Exponente += 1
    return Decimal


def Decimal_Binario(decimal, bits):
    inverso = []
    if decimal == 1:
        binario = "1"
        while True:
            if len(binario) < bits:
                binario = "0" + binario
            elif len(binario) == bits:
                return binario
    while True:
        Resto = decimal % 2
        Cociente = decimal//2
        if Cociente != 1:
            inverso.append(Resto)
            decimal = Cociente
        elif Cociente == 1:
            inverso.append(Resto)
            inverso.append(Cociente)
            break
    Máximo = len(inverso)
    binario = ""
    for i in range(Máximo-1, -1, -1):
        binario = binario+str(inverso[i])
    while True:
        if len(binario) < bits:
            binario = "0" + binario
        elif len(binario) == bits:
            return binario


# Aquí tenemos los caracteres con los que trabaja la clase Criptografía, el número de caracteres
# deben ser uno menos a un impar (para que se pueda cumplir la propiedad de números de inversos sea uno menor al primo).
Letras_L = (",", ".", "A", "B", "C", "D", "E", "F", "G", "H",
            "I", "J", "K", "L", "M", "N", "Ñ", "O", "P", "Q",
            "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0",
            "1", "2", "3", "4", "5", "6", "7", "8", "9", "¿",
            "?", "!", "¡", "-", ":", "a", "á", "b", "c", "d",
            "e", "é", "f", "g", "h", "i", "í", "j", "k", "l",
            "m", "n", "ñ", "o", "ó", "p", "q", "r", "s", "t",
            "u", "ú", "v", "w", "x", "y", "z", "*", ";", "=",
            "|", '"', "'", "·", "$", "%", "&", "/", "(", ")",
            "[", "]", "{", "}", "_", "+")

# Creamos una lista binaria para poder trabajar con ella siqueremos.

Binario_L = []
for i in range(1, len(Letras_L)+1):
    Binario = Decimal_Binario(i, 8)
    Binario_L.append(Binario)

# Creamos unos diccionarios que permitan cambiar entre binario y caracter.

Binario_D, Letras_D = {}, {}
for i in range(0, len(Letras_L)):
    Letras_D[Binario_L[i]] = Letras_L[i]
    Binario_D[Letras_L[i]] = Binario_L[i]

Text = TypeVar("Text")
nothing = TypeVar("nothing")
file = TypeVar("file")


@dataclass(frozen=True, order=True)
class Text:
    mensaje: str
    canal: int
    módulo: int = len(Letras_L)+1
    conteo: int = 0

    @staticmethod
    def of(mensaje: str, canal: int) -> Text:
        return Text(mensaje, canal)

    @property
    def Code(self: Text) -> Text:
        if self.__conteo == 0:
            criptación = ""
            for i in self.mensaje:
                if i == " ":
                    criptación = " " + criptación
                    continue
                elif i == "\n":
                    criptación = "\n" + criptación
                    continue
                binario1 = Binario_D[i]
                decimal1 = Binario_Decimal(binario1)
                decimal2 = (decimal1*self.canal) % self.módulo
                binario2 = Decimal_Binario(decimal2, 8)
                criptación = Letras_D[binario2] + criptación
                self.mensaje = criptación
            self.__conteo = 1
            return self.mensaje
        elif self.__conteo == 1:
            return Text("El mensaje ya está encriptado.")

    @property
    def Decode(self: Text) -> Text:
        if self.__conteo == 1:
            descriptación = ""
            for valor in range(0, self.módulo):
                condición = (self.canal*valor) % self.módulo
                if condición != 1:
                    continue
                elif condición == 1:
                    inverso = valor
                    break
            for i in self.mensaje:
                if i == " ":
                    descriptación = " " + descriptación
                    continue
                elif i == "\n":
                    descriptación = "\n" + descriptación
                    continue
                binario1 = Binario_D[i]
                decimal1 = Binario_Decimal(binario1)
                decimal2 = (decimal1*inverso) % self.módulo
                binario2 = Decimal_Binario(decimal2, 8)
                descriptación = Letras_D[binario2] + descriptación
                self.mensaje = descriptación
            self.__conteo = 0
            return self.mensaje
        elif self.__conteo == 0:
            return Text("El mensaje aún no ha sido encriptado.")

    @property
    def Create_Text(self: Text) -> file:
        Info = open(f"{self}.txt", "w")
        Info.write(self.mensaje)
        Info.close()

    @property
    def Borrow_Text(self: Text) -> nothing:
        os.remove(f"{self}.txt")

    @property
    def Append_Text(self: Text) -> file:
        Info = open(f"{self}.txt", "a")
        Info.write(self.mensaje)
        Info.close()

    def Read_Text(self, inicio: int, final: int) -> nothing:
        conteo = 0
        with open(f"{self}.txt", encoding="latin-1") as f:
            for linea in f:
                conteo += 1
                if inicio <= conteo <= final:
                    print(linea, end='')
                elif inicio > conteo:
                    continue
                elif final < conteo:
                    break

    def __str__(self):
        return f"{Decimal_Binario(self.canal, int(sqrt(self.canal))+1)}"
