from Tool import Easy as E, Math as M
import os
import sqlite3
import folium
import time
import webbrowser
import math
from typing import TypeVar

################################################################
# Salidas
################################################################

map = TypeVar("map")
graph = TypeVar("graph")
barchart = TypeVar("barchart")
data_base = TypeVar("data base")
txt = TypeVar("txt")

################################################################
#  Diccionarios.
################################################################
Easy_Info = {  # Ayuda a acceder a una de las columnas.
    "date": 0,
    "state": 1,
    "fips": 2,
    "cases": 3,
    "deaths": 4
    }

Easy_Month = {  # Permite eliminar el error de que se pase a un mes anterior.
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 31, 10: 30, 11: 30, 12: 31
    }

Easy_Number = {  # Para cambiar entre integer y string y en ese paso realizar algún cálculo.
    1: "01", 2: "02", 3: "03", 4: "04", 5: "05", 6: "06", 7: "07", 8: "08", 9: "09", 10: 10,
    11: 11, 12: 12, 13: 13, 14: 14, 15: 15, 16: 16, 17: 17, 18: 18, 19: 19, 20: 20,
    21: 21, 22: 22, 23: 23, 24: 24, 25: 25, 26: 26, 27: 27, 28: 28, 29: 29, 30: 30
    }

Fila = {  # Permite acceder fácilmete a alguna sección de un documento de texto.
    "Presentacion_inicio": 1, "Presentacion_final": 12,
    "Bloque1_inicio": 13, "Bloque1_final": 24,
    "Bloque2_inicio": 25, "Bloque2_final": 28,
    "Bloque3_inicio": 29, "Bloque3_final": 32,
    "Bloque4_inicio": 33, "Bloque4_final": 36,
    "Otros_inicio": 37, "Otros_final": 50,
    }

Places = {"Alabama": (32.318230, -86.902298), "Alaska": (66.160507, -153.369141),"Arizona": (34.048927, -111.093735), "Arkansas": (34.799999, -92.199997), "California": (36.778259, -119.417931), "Colorado": (39.113014, -105.358887), "Connecticut": (41.599998, -72.699997), "Delaware": (39.000000, -75.500000), "District of Columbia": (38.942142, -77.025955), "Florida": (27.994402, -81.760254),
          "Georgia": (33.247875, -83.441162), "Guam": (13.444304, 144.793732), "Hawaii": (19.741755, -155.844437), "Idaho": (44.068203, -114.742043), "Illinois": (40.000000, -89.000000), "Indiana": (40.273502, -86.126976), "Iowa": (42.032974, -93.581543), "Kansas": (38.500000, -98.000000), "Kentucky": (37.839333, -84.270020), "Louisiana": (30.391830, -92.329102),
          "Maine": (45.367584, -68.972168), "Maryland": (39.045753, -76.641273), "Massachusetts": (42.407211, -71.382439), "Michigan": (44.182205, -84.506836), "Minnesota": (46.392410, -94.636230), "Mississippi": (35.514706, -89.912506), "Missouri": (38.573936, -92.603760), "Montana": (46.965260, -109.533691), "Nebraska": (41.500000, -100.000000), "Nevada": (39.876019, -117.224121),
          "New Hampshire": (44.000000, -71.500000), "New Jersey": (39.833851, -74.871826), "New Mexico": (34.307144, -106.018066), "New York": (40.730610, -73.935242), "North Carolina": (35.782169, -80.793457), "North Dakota": (47.650589, -100.437012), "Northern Mariana Islands": (15.1064, 145.7065), "Ohio": (40.367474, -82.996216), "Oklahoma": (36.084621, -96.921387), "Oregon": (44.000000, -120.500000),
          "Pennsylvania": (41.203323, -77.194527),"Puerto Rico": (18.200178, -66.664513), "Rhode Island": (41.700001, -71.500000),"South Carolina": (33.836082, -81.163727),"South Dakota": (44.500000, -100.000000), "Tennessee": (35.860119, -86.660156), "Texas": (31.000000, -100.000000), "Utah": (39.419220, -111.950684), "Vermont": (44.000000, -72.699997), "Virgin Islands": (18.436539, -64.618103),
          "Virginia": (37.926868, -78.024902), "Washington": (47.751076, -120.740135), "West Virginia": (39.000000, -80.500000),"Wisconsin": (44.500000, -89.500000), "Wyoming": (43.075970, -107.290283)
        }


################################################################
#  Textos.
################################################################
m_State = """-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
'Alabama' [01]                | 'Georgia' [13]     | 'Maine' [23]           | 'New Hampshire' [33]               | 'Pennsylvania' [42]       | 'Virginia' [51]
'Alaska' [02]                 | 'Guam' [66]        | 'Maryland' [24]        | 'New Jersey' [34]                  | 'Puerto Rico' [72]        | 'Washington' [53]
'Arizona' [04]                | 'Hawaii' [15]      | 'Massachusetts' [25]   | 'New Mexico' [35]                  | 'Rhode Island' [44]       | 'West Virginia' [54]
'Arkansas' [05]               | 'Idaho' [16]       | 'Michigan' [26]        | 'New York' [36]                    | 'South Carolina' [45]     | 'Wisconsin' [55]
'California' [06]             | 'Illinois' [17]    | 'Minnesota' [27]       | 'North Carolina' [37]              | 'South Dakota' [46]       | 'Wyoming' [56]
'Colorado' [08]               | 'Indiana'    [18]  | 'Mississippi' [28]     | 'North Dakota' [38]                | 'Tennessee' [47]          |
'Connecticut' [09]            | 'Iowa' [19]        | 'Missouri' [29]        | 'Northern Mariana Islands' [69]    | 'Texas' [48]              |
'Delaware' [10]               | 'Kansas' [20]      | 'Montana' [30]         | 'Ohio' [39]                        | 'Utah' [49]               |
'District of Columbia' [11]   | 'Kentucky' [21]    | 'Nebraska' [31]        | 'Oklahoma' [40]                    | 'Vermont' [50]            |
'Florida' [12]                | 'Louisiana' [22]   | 'Nevada' [32]          | 'Oregon' [41]                      | 'Virgin Islands' [78]     |
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""

m_Info = """1/En el módulo de Covid podemos encontrar las siguientes funciones:

    +Easy_info: permite acceder en una de las listas fácilmete a una de sus columnnas.

    +Easy_Month: permite que si en un día se llega a cero pase al mes anterior.

    +Easy_Number: Python no permite el uso de '0x' en un numero, por tanto, he tenido que
                  crear un diccionario que los pase a string con el 0 delante si es necesario.

    +Fila: Facilita la lectura de los archivos.

    *m_State: Contiene los estados que contiene el documento Excel.

    *m_Info: Contiene esta información.

    *m_Month: Advierte de como se debe introducir una fecha.

    *m_Columns: Nos informa acerca de las columnas que tiene el documento.

    *m_Blocks: Nos informa de las partes en las que esta dividido el módulo Program.Program-When_Up: Nos informa cuando un estado supero cierta cantidad de casos.

    -Graph_State: Realiza una gráfica de la evolución de los casos de coronavirus diarios.

    -Read_Easy: Muestra los datos de forma que sea más comprensible.

    -Barchar_Day: Realiza un diagrama de barras de los casos de coronavirus de un día en concreto.

    -Get_Info: Permite acceder a la información de una de las columnas de forma sencilla.

    -Read_Count: Permite saber el número de veces que se repite un dato.

    -Read_Basic: Parecido a un print, pero en vez de mostrar la información en horizontal, la muestra en vertical.

    -Show_Something: Muestra los valores de uno de los posibles columnas (date, state, fip, cases, deaths),
                     eliminando los que esten repetidos.

    -See_State: Para poder tener los datos de un estado a lo largo del tiempo.

    -See_Date: Permite comparar las columnas en una determinada fecha.

    -Order_State: Ordena la lista alfabéticamente en función de los estados.

    -Show_All:Muestra los valores de uno de los posibles columnas (date, state, fip, cases, deaths).

    -Count_Something: Realiza un conteo de un dato.

    -Check_Column: Hace que solo podamos introducir una de las columnas del documento excel.

    -Len_Text: Nos permite saber cuantas líneas tiene un fichero.

    -Create_DB_Covid: Crea una base de datos que es muy útil para ver si los resultados son correctos.

    -Percentage_Day: Permite obtener una lista de tuplas en la que contiene el estado y el porcentaje (casos o muertes).

    -Cases_Death: Permite que al poner 'cases' o 'deaths' lo pase al número de su correspondiente columna.

2/En el módulo de Math podemos encontrar las siguientes funciones, la mayoría son del notebook CalculosGeometriayTipos_v4 de José Miguel Toro Bonilla:

    -Draw_Piechar (de Miguel Toro): Dibuja un gráfico circular.

    -Draw_Barchart (de Miguel Toro): Dibuja un diagrama de barras.

    -Draw_Multline (de Miguel Toro): Dibuja una gráfica formada por la unión de puntos.

    -Points: Para tener puntos para la función anterior.

    -Input_Zero: Rellena la lista de ceros y, por tanto, inserta los valores necesarios
                para poder realizar su estudio.

3/En el módulo de Easy podemos encontrar las siguientes funciones:

    -Read: Permite abrir documentos de texto fácilmente pudiendo indicar de que línea a que línea.

    -Create_Text: Es capaz de crear un texto que pude ser leído en partes usando la función Read.

    -Change: Una vez el programa ha iniciado, permite cambiar entre las diferentes secciones sin tener que arrancarlo de nuevo. 

    -Check_Number: Para evitar en la función 'input' el error ValueError a la hora de insertar números.

    -Check_Stade: Hace que la única posibilidad a introducir sea uno de los estados en el documento excel.

    -Check_Date: Hace que solo se pueda introducir una de las fechas disponibles en el documento excel.

    -Limit: limita los posibles valores que se pueden utilizar en un 'input' para evitar errores en cálculos.

    -Check_YES_NO: Hace que solo podamos introducir si o no.

    -Lines:añade una línea en la que se inserta el nombre del programa. 

    -Slow: hace que el texto aparezca más lentamente, lo encontre en:
            https://stackoverrun.com/es/q/5436683

4/ El módulo Program nos permite utilizar las principalProgramiones de una manera más amigable.

5/ En el módulo Fun_Prin_Test encontramos las funciones más avanzadas de una manera que sea muy fácil trabajar con ellas.

6/ En el módulo class encontramos las clases que he ido creando a lo largo de la creación de este programa.
"""

m_Month = """Desde el 21 de enero del 2020 hasta el 1 de noviembre de 2020.

{01: Enero, 02: Febrero, 03: Marzo, 04: Abril, 05: Mayo, 06: Junio, 07: Julio, 
 08:Agosto, 09: Septiembre, 10: Octubre, 11: Noviembre, 12: Diciembre}
"""
m_Columns ="""La lista esta formada por las siguientes columnas:

-cases

-deaths

-date

-state

-fips
"""
m_Blocks = """Elija el bloque:
---------------------------------------------------
[1] Bloque 1.

[2] Bloque 2.

[3] Bloque 3.

[4] Bloque 4.

[5] Otros.
---------------------------------------------------
Elija la seccion:
---------------------------------------------------
[1] Mostrar cuando se ha alcanzado cierta cifra de casos en cierto estado.

[2] Permite estudiar el avance del Covid a lo largo del tiempo.

[3] Permite estudiar el Covid en diferentes estados en un dia en concreto.

[4] Mostrar lo datos que tiene una columna.

[5] Poder ver el numero de veces que se repite un dato.
---------------------------------------------------
Elija la seccion:
---------------------------------------------------
[x] Vacio.
---------------------------------------------------
Elija la seccion:
---------------------------------------------------
[x] Vacio.
---------------------------------------------------
Elija la seccion:
---------------------------------------------------
[x] Vacio.
---------------------------------------------------
Otros:
---------------------------------------------------
[1] Informacion acerca de las funciones internas de este programa.

[2] Mostrar grafica de la evolucion del coronavirus en un estado.

[3] Mostrar un diagrama de barras que compara los casos de coronavirus.

[4] Porcentaje de casos o muertes en un dia.

[5] Ver un mapa con la información.
---------------------------------------------------
"""


################################################################
#  Funciones.
################################################################
def When_Up(info: list, estado: str, casos: int, columna: str, test: str="SI"):
    """
    Cuando un estado ha superado una cierta cifra de casos.
    """
    número = Cases_Death(columna) # Para tener el número del segundo índice de la lista a estudiar. 
    while True:
        Lista1 = []
        for i in range(0, len(info)):
            if info[i][1] == estado and info[i][número] < casos or info[i][1] != estado:
                continue
            elif info[i][1] == estado and info[i][número] >= casos:
                Lista1.append(info[i])
                break
        # Parte en la que se pretende mostrar la información en pantalla de forma elegante.
        if test == "SI":
            return número, Lista1
        # =======================================================
        if número == 3:
            print(f"En el estado de {Lista1[0][1]} fue superado el número de casos de {casos}")
            print(f"casos en la fecha {Lista1[0][0]}, habiendo hasta ese momento ")
            print(f"{Lista1[0][número+1]} fallecidos y {Lista1[0][número]} casos.")
            break
        elif número == 4:
            print(f"En el estado de {Lista1[0][1]} fue superado el número de casos de {casos}")
            print(f"muertes en la fecha {Lista1[0][0]}, habiendo hasta ese momento ")
            print(f"{Lista1[0][número]} fallecidos y {Lista1[0][número-1]} casos.")
            break
        # =======================================================


def See_State(info: list, estado: str) -> list:
    """
    Permite tener una lista de tuplas en la que la columna estado es la misma en todas.
    """
    while True:
        Lista1 = []  # Si de alguna manera está vacía, es que el estado introducido no está disponible, pero actualmente eso es muy difícil que pase.
        for i in range(0, len(info)):
            if info[i][1] == estado:
                Lista1.append(info[i])
            elif info[i][1] != estado:
                continue
        break
    return Lista1


def See_Date(info: list, mes: str, día: str, respuesta: str) -> list:
    """
    Permite compara las columnas en una determinada fecha.
    """
    while True:
        Lista1 = []  # Si de alguna manera está vacía, es que la fecha introducido no está disponible, pero actualmente eso es muy difícil que pase.
        for i in range(0, len(info)):
            if respuesta == "SI":  # Si respuesta = "SI", estudia todos los casos de ese día.
                if info[i][0] == f"2020-{mes}-{día}":
                    Lista1.append(info[i])
                elif info[i][0] != f"2020-{mes}-{día}":
                    continue
            elif respuesta == "NO":  # Si respuesta = "NO", estudia solo los casos de ese día.
                if int(día)-1 >= 1:
                    if info[i][0] == f"2020-{mes}-{día}" or info[i][0] == f"2020-{mes}-{Easy_Number[int(día)-1]}":
                        Lista1.append(info[i])
                    elif info[i][0] != f"2020-{mes}-{día}" or info[i][0] == f"2020-{mes}-{Easy_Number[int(día)-1]}":
                        continue
                elif int(día)-1 < 1:
                    if info[i][0] == f"2020-{mes}-{día}" or info[i][0] == f"2020-{Easy_Number[int(mes)-1]}-{Easy_Month[int(mes)-1]}":
                        Lista1.append(info[i])
                    elif info[i][0] != f"2020-{mes}-{día}" or info[i][0] == f"2020-{Easy_Number[int(mes)-1]}-{Easy_Month[int(mes)-1]}":
                        continue
        break
    return Lista1


def Show_Something(info: list, columna: str) -> list:
    """
    Permite ver los valores posibles en una de las columnas del excel.
    """
    Lista1 = []
    for i in range(0, len(info)):
        condición = info[i][Easy_Info[columna]] in Lista1  # Condición que permite acceder a una dterminada columna.
        if condición is False:
            Lista1.append(info[i][Easy_Info[columna]])
        elif condición is True:
            continue
    return Lista1


def Count(info: list, nombre: str, test: str= "SI") -> int:
    """
    Permite saber el número de veces que se repite un dato.
    """
    número = 0
    for i in range(0,len(info)):
        número += info[i].count(nombre)
    if número == 0:
        decimal = int(nombre)
        for i in range(0, len(info)):
            número += info[i].count(decimal)
        if número == 0:
            número = False
    if test == "SI":
        return número
    # =======================================================
    # Parte en la que se pretende mostrar la información en pantalla de forma elegante.
    if número == False:
        print(f"No se ha encontrado {nombre} en la lista.")
    else:
        print(f"El número de veces que se ha encontrado {nombre} es de {número} veces.")
    # =======================================================


def Graph_State(info: list, estado: str, columna: str) -> graph:
    """
    Dibuja una gráfica sobre la evolución del coronavirus en un estado a lo largo del tiempo.
    """
    Lista1 = See_State(info, estado)  # Obtengo la información de ese estado en el documento excel.
    if columna == "cases":
        Lista2 = Show_Something(Lista1, columna)  # Creo una lista que solo contenga los casos.
        M.Draw_Multiline(M.Points(Lista2), "Cases", "Days", str(estado))  # Función que nos permite crear unas coordenadas para la gráfica.
    elif columna == "deaths":
        Lista2 = Show_Something(Lista1, columna)  # Creo una lista que solo contenga los casos.
        M.Draw_Multiline(M.Points(Lista2), "Deaths", "Days", str(estado))  # Función que permite crear una gráfica a partir del número de casos (para ello he tenido que crear las coordenadas).



def Barchart_Day(info: list, mes: str, día: str, respuesta: str, columna: str) -> barchart:
    """
    Dibuja un diagrama de barras en el que se comparan en un día diferentes estados.
    """
    if respuesta == "NO":  # Permitirá añadir el número de estados que se quierán estudiar.
        Lista1, Lista2 = [], []
        continuar = "SI"
        while True:
            if continuar == "SI":
                estado = E.Check_State(info)
                Lista1.append(estado)
                continuar = input("¿Quiere continuar?").upper()
            elif continuar == "NO":
                break
        for i in range(0, len(info)):
            if info[i][1] in Lista1:
                Lista2.append(info[i])
        info = Lista2
    modificada = See_Date(info, mes, día, "SI")  # Obtenemos la información de esos estados en ese día, lo de si es paraa que sea todos los casos.
    z = M.Input_Zero(modificada, info, respuesta)  # Añade los valores que no tiene un valor (en el documento excel no están cuando tiene 0 casos)
    if respuesta == "SI":
        eje_x, datos = Show_All(z, "fips"), Show_All(z, columna)  # Obtenemos lo valores para el eje x y el eje z.
    elif respuesta == "NO":
        eje_x, datos = [], []  # Obtenemos lo valores para el eje x y el eje z de los estados que hemos pedido al principio.
        for i in range(0, len(z)):
            eje_x.append(z[i][1])
            if columna == "cases":
                datos.append(z[i][3])
            elif columna == "deaths":
                datos.append(z[i][4])
    if respuesta == "NO":
        M.Draw_Barchart(eje_x, datos, title=f"Casos de coronavirus el {modificada[0][0]}.", y_label=columna.title(), x_label="States")  # Dibuja el diagrma de barras.
    elif respuesta == "SI":
        M.Draw_Barchart(eje_x, datos, title=f"Casos de coronavirus el {modificada[0][0]}.", y_label=columna.title(), x_label="FIPS")  # Dibuja el diagrma de barras.


def Percentage_Day(info: list, mes: str, día: str, columna: str, respuesta: str, test: str= "SI") -> str:
    """
    Permite obetener los porcentajes tanto de fallecimientos como de casos en un día.
    """
    if respuesta == "NO":
        Lista1, Lista2 = [], []
        continuar = "SI"
        while True:
            if continuar == "SI":
                estado = E.Check_State(info)
                Lista1.append(estado)
                continuar = input("¿Quiere continuar?").upper()
            elif continuar == "NO":
                break
    modificada, total = See_Date(info, mes, día, respuesta="SI"), 0
    Lista3 = []
    numero = Cases_Death(columna)
    for i in range(0, len(modificada)):
        total += modificada[i][numero]
    for i in range(0, len(modificada)):
        porcentaje = round(modificada[i][numero]*100/total, 3)
        tupla1 = (modificada[i][1], porcentaje)
        Lista3.append(tupla1)
        tupla1 = ()
    if respuesta == "NO":
        for i in range(0, len(Lista3)):
            if Lista3[i][0] in Lista1:
                Lista2.append(Lista3[i])
        Lista3 = Lista2
    if test == "SI":
        return Lista3
    # =======================================================
    for i in range(0, len(modificada)):
        if columna == "cases":
            print(f"El porcentaje de casos en {Lista3[i][0]} es {Lista3[i][1]} %.")
        elif columna == "deaths":
            print(f"El porcentaje de muertes en {Lista3[i][0]} es {Lista3[i][1]} %.")
    # =======================================================
    
def Get_Info(info: list, columna: str, respuesta: str, test: str="SI"):
    """
    Obtiene la información de cualquier columna('date', 'state', 'fips', 'cases' y 'deaths').
    """
    modificada = Show_Something(info, columna)

    # Parte en la que se pretende mostrar la información en pantalla de forma elegante.
    cadena = ""
    if respuesta == "SI":  # Se aportarán todos los datos de la columna pedida.
        for i in range(0, len(modificada)):
            if i == len(modificada)-1:
                cadena = cadena + str(modificada[i])+"."
            elif i % 10 == 0 and i != 0:
                cadena = cadena + "\n"
            elif i == len(modificada)-2:
                cadena = cadena + str(modificada[i])+" y "
            else:
                cadena = cadena + str(modificada[i])+", "
    elif respuesta == "NO":  # Se aportará un cierto intervalo.
        print("\nElija el intervalo:")
        inferior = int(input("Introduzca el primer número del intervalo: "))
        superior = int(input(f"Introduzca el último número del intervalo(máximo={len(modificada)}): "))
        for i in range(inferior-1, superior):
            if i == superior-1:
                cadena = cadena + str(modificada[i])+"."
            elif i == superior-2:
                cadena = cadena + str(modificada[i])+" y "
            else:
                cadena = cadena + str(modificada[i])+", "
            if i % 10 == 0 and i != 0:
                cadena = cadena + "\n"
    if test == "SI":
        return cadena
    # =======================================================
    if columna == "date":
        print(f"Las fechas en este documento son:\n{cadena}")
    elif columna == "state":
        print(f"Los estados en este documento son:\n{cadena}")
    elif columna == "fips":
        print(f"Los fips en este documento son:\n{cadena}")
    elif columna == "cases":
        print(f"Valores de casos en el documento:\n{cadena}")
    elif columna == "deaths":
        print(f"Valores de muertes en el documento:\n{cadena}")
    # =======================================================

def Generate_Map(info: list, respuesta: str) -> map: # copiado de centros sanitarios
    states, Lista1 = Show_Something(info, "state"), []
    centro_mapa = Mean_Coordinates(info)
    mapa = Create_Map(centro_mapa[0], centro_mapa[1])
    for i in range(0, len(states)):
        if respuesta == "SI":
            desplegable = f"{info[i][1]}"
            etiqueta = f"Casos:_{info[i][3]}.<br>Muertes:_{info[i][4]}."
        elif respuesta == "NO" and states[i] not in Lista1:
            desplegable = f"{info[i][1]}"
            etiqueta = f"Casos:_{info[i][3]}.<br>Muertes:_{info[i][4]}."
            Lista1.append(states[i])
        marcador = Create_Marker(Places[info[i][1]][0], Places[info[i][1]][1], etiqueta, desplegable)
        marcador.add_to(mapa)
    página_web, dirección, inicio_dirección = f"mapa_Covid_en_{info[0][0]}.html", "", "C:/"
    mapa.save(f"../out/{página_web}")
    for resto_dirección, _, archivos in os.walk(inicio_dirección):
        if página_web in archivos:
            dirección = os.path.join(resto_dirección, página_web)
            break
    webbrowser.open(dirección)
    time.sleep(0.5)
    os.remove(dirección)


################################################################
#  Funciones auxiliares.
################################################################
def Read_Basic(info: list):
    """
    Permite ver las tuplas dentro de la lista de forma básica.
    """
    for i in range(0, len(info)):
        print(info[i])


def Order_States(info: list) -> list:
    """
    Ordena el documento excel a partir de la columna 'states' ordenando alfabeticamente.
    """
    Lista1, Lista2 = Show_Something(info, "state"), []
    Lista1.sort()
    while True:
        for i in range(0, len(info)):
            if info[i][1] == Lista1[0]:
                Lista2.append(info[i])
            else:
                continue
        Lista1.remove(Lista1[0])
        if Lista1 == []:
            break
    del(Lista1)
    return Lista2


def Show_All(info: list, columna: str) -> list:
    """
    Permite ver todos lo valores en una de las columnas del documento excel.
    """
    Lista1 = []
    for i in range(0, len(info)):
        Lista1.append(info[i][Easy_Info[columna]])
    return Lista1


def Check_Column(mensaje: str) -> str:
    """
    Hace que solo podamos introducir una de las columnas del documento excel.
    """
    columna = input(mensaje).lower()
    while True:
        if columna in Easy_Info:
            break
        else:
            print("\nRespuesta no válida.")
            columna = input("Introduzca una de las columnas: ").lower()
            print()
    return columna


def Len_Text(fichero: txt) -> int:
    """
    Nos permite saber cuántas lineas tiene un fichero.
    """
    try:
        fichero = open(fichero, 'r')
        longitud = len(fichero.readlines())
        fichero.close()
        return longitud
    except FileNotFoundError:
        print(f"El archivo '{fichero}' no está disponible")


def Create_DB_Covid(info: list, archivo="Covid_USA") -> data_base:
    """
    Crea una base de datos que es muy útil para ver si los resultados son correctos.
    """
    miConexion = sqlite3.connect(archivo)
    miCursor = miConexion.cursor()
    estados = Show_Something(info, "state")
    while True:
        modificada, nombre = [], estados[0]
        instruccion1 = "CREATE TABLE '%s' (DATE, CASES, DEATHS)" % nombre
        instruccion2 = "INSERT INTO '%s' VALUES (?,?,?)" % nombre
        miCursor.execute(instruccion1)
        for i in range(0, len(info)):
            if info[i][1] == estados[0]:
                tupla1 = (info[i][0], info[i][3], info[i][4])
                modificada.append(tupla1)
                tupla1 = ()
        estados.pop(0)
        miCursor.executemany(instruccion2, modificada)
        if estados == []:
            break
    miConexion.commit()
    miConexion.close()


def Cases_Death(columna: str)-> int:
    """
    Permite que al poner ‘cases’ o ‘deaths’ lo pase al numero de su correspondiente columna.
    """
    while True:
        if columna == "cases" or columna == "casos":
            numero = 3
            return numero
        elif columna == "deaths" or columna == "muertes":
            numero = 4
            return numero
        else:
            columna = input("Introduzca muertes o casos: ")

def Create_Map(latitud, longitud, zoom=3):
    mapa = folium.Map(location=[latitud, longitud], tittle = "Stamen Terrain", zoom_start=zoom)
    return mapa
 
def Create_Marker(latitud, longitud, etiqueta, desplegable):
    marcador = folium.Marker(location=[latitud,longitud], popup=etiqueta, tooltip=desplegable, icon=folium.Icon(color='red', icon=f'info-sign')) 
    return marcador
 
def Euclidean_Distance(coordenada_1, coordenada_2) -> float: # copiado de centros sanitarios
    resta_latitud, resta_longitud = (coordenada_2[0] - coordenada_1[0]), (coordenada_2[1] - coordenada_1[1])
    distancia_euclidea = math.sqrt(resta_latitud**2 + resta_longitud**2)
    return distancia_euclidea
 
def Mean_Coordinates(info): # copiado de centros sanitarios
    sumatorio_latitud, sumatorio_longitud = 0, 0
    for i in range(0, len(info)):
        sumatorio_latitud += Places[info[i][1]][0]
        sumatorio_longitud += Places[info[i][1]][1]
        valores = len(Show_Something(info, "state"))
    media_latitud = sumatorio_latitud/valores
    media_longitud = sumatorio_longitud/valores
    return media_latitud, media_longitud

################################################################
#  Funciones para Program.
################################################################
def Read_Easy(info: list, columna: str, respuesta: str, estado: str="0", mes="0", día: str="0"):
    """
    Permite obterner información fácil de comprender(esta función realiza la función equivalente 
    a varias funciones que se acceden insertando ciertos string).
    """
    if columna == "date":  # Empezamos con la parte de la función que nos permite estudiar una fecha.
        info = Order_States(See_Date(info, mes, día, respuesta))  # Función que pormite extraer uno o dos días (permite realizar una resta entre el día más lejano y el más cercano a nosotros, puede ocurrir que salga negativo) del documente excel.
    elif columna == "state":  # Empezamos con la parte de la función que nos permite estudiar un estado.
        info = See_State(info, estado)  # Función que permite extraer la información de un estado.
    # Parte en la que se pretende mostrar la información en pantalla de forma elegante.
    if columna == "date":
        if respuesta == "SI":  # Si  respuesta = "SI", realizará un estudio de todos los casos hasta el momento.
            print(f"En la fecha {info[1][0]}:\n") # Para poder comprenderlo posteriormente más fácilmete.
        elif respuesta == "NO":  # Si  respuesta = "NO", realizará un estudio de los casos de ese día.
            print(f"En la fecha {info[0][0]}:\n") # Para poder comprenderlo posteriormente más fácilmete.
        Lista1 = []
        for i in range(0, len(info)):
            if respuesta == "SI":
                print(f"En {info[i][1]} con un código o fip de {info[i][2]}")
                print(f"tuvo {int(info[i][3])} casos y {int(info[i][4])} muertes.\n")
            condicion = info[i][1] in Lista1  # Impongo que únicamente estudie aquellos valores que en la columna 'date' coinciden con la fecha introducida.
            if respuesta == "NO" and condicion:
                print(f"En {info[i][1]} con un código o fip de {info[i][2]}")
                print(f"tuvo {int(info[i][3])-int(info[i-1][3])} casos y {int(info[i][4])-int(info[i-1][4])} muertes.\n")
            Lista1.append(info[i][1])
        del(Lista1)
    elif columna == "state":
        print(f"En el estado {info[0][1]}:\n")  # Para poder comprenderlo posteriormente más fácilmete.
        for i in range(0, len(info)):
            if i == 0 or respuesta == "SI":
                print(f"En la fecha {info[i][0]} tuvo {info[i][3]} casos y {info[i][4]} muertes.\n")
            else:
                print(f"En la fecha {info[i][0]} tuvo {int(info[i][3])-int(info[i-1][3])} casos y {int(info[i][4])-int(info[i-1][4])} muertes.\n")



    