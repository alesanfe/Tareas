import csv
from Tool import Covid as C, Easy as E
from Tool.Class import Text
from datetime import datetime


# Por favor, procure siempre darle a apagar para que elimine todos loa archivos de texto.

Info = Text(C.m_Info, 7); Info.Create_Text
Limite_Info = C.Len_Text(f"{Info}.txt")
State = Text(C.m_State, 13); State.Create_Text
Limite_State = C.Len_Text(f"{State}.txt")
Month = Text(C.m_Month, 17); Month.Create_Text
Limite_Month = C.Len_Text(f"{Month}.txt")
Columns = Text(C.m_Columns, 23); Columns.Create_Text
Limite_Colums = C.Len_Text(f"{Columns}.txt")
Blocks = Text(C.m_Blocks, 73); Blocks.Create_Text


with open('../data/covid_by_state.csv', encoding='utf-8') as f:
    lector = csv.reader(f)
    next(lector)
    GENERAL = [(date, state, int(fips), int(cases), int(deaths)) for date, state, fips, cases, deaths in lector]

if __name__ == '__main__':
    RESPUESTA = 30
    E.Slow(f"Covid_USA ha iniciado. {datetime.now()}")
    print("\n")
    while RESPUESTA < 40:
        Blocks.Read_Text(C.Fila["Presentacion_inicio"], C.Fila["Presentacion_final"])
        BLOQUE = str(E.Limit("Introduzca lo que quiere hacer: ", 6, "negativo"))
        RESPUESTA = 30

        if BLOQUE == "1":
            E.Lines("Bloque 1.")
            while RESPUESTA < 35:
                Blocks.Read_Text(C.Fila["Bloque1_inicio"], C.Fila["Bloque1_final"])
                SECCION = str(E.Limit("Introduzca lo que quiere hacer: ", 6, "negativo"))
                RESPUESTA = 25

                if SECCION == "1":
                    E.Lines("Busqueda de casos o muertes en un país.")
                    while RESPUESTA < 30:
                        State.Read_Text(0, Limite_State)
                        print()
                        estado = E.Check_State(GENERAL)
                        print()
                        Columns.Read(0, 4)
                        print()
                        columna = C.Check_Column("Intoduzca 'deaths' o 'cases': ")
                        print()
                        if columna == "deaths":
                            casos = E.Check_Number("Introduzca el número de fallecidos: ", int)
                        elif columna == "cases":
                            casos = E.Check_Number("Introduzca el número de casos: ", int)
                        print()
                        C.When_Up(GENERAL, estado, casos, columna, test="NO")
                        print()
                        RESPUESTA = E.Change(RESPUESTA)
                        if RESPUESTA < 30:
                            print()
                    E.Lines("Busqueda de casos o muertes en un país.")

                elif SECCION == "2":
                    E.Lines("Estudio de un estado.")
                    while RESPUESTA < 30:
                        State.Read_Text(0, Limite_State)
                        print()
                        estado = E.Check_State(GENERAL)
                        print()
                        respuesta = E.Check_Yes_NO("¿Todos los casos? ")
                        print()
                        C.Read_Easy(GENERAL, "state", respuesta, estado=estado)
                        RESPUESTA = E.Change(RESPUESTA)
                        if RESPUESTA < 30:
                            print()
                    E.Lines("Estudio de un estado.")

                elif SECCION == "3":
                    E.Lines("Casos o muertes en un día.")
                    while RESPUESTA < 30:
                        Month.Read_Text(0, Limite_Month)
                        print()
                        mes, día = E.Check_Date(GENERAL)
                        print()
                        respuesta = E.Check_Yes_NO("¿Todos los casos? ")
                        print()
                        C.Read_Easy(GENERAL, "date", respuesta, mes=mes, día=día)
                        RESPUESTA = E.Change(RESPUESTA)
                        if RESPUESTA < 30:
                            print()
                    E.Lines("Casos o muertes en un día.")

                elif SECCION == "4":
                    E.Lines("Datos disponibles.")
                    while RESPUESTA < 30:
                        Columns.Read_Text(0, Limite_Colums)
                        print()
                        columna = C.Check_Column("Introduzca la columna de la que quiere saber algo: ")
                        print()
                        respuesta = E.Check_Yes_NO("¿Quiere todos los valores? ")
                        print()
                        C.Get_Info(GENERAL, columna, respuesta)
                        print()
                        RESPUESTA = E.Change(RESPUESTA)
                        if RESPUESTA < 30:
                            print()
                    E.Lines("Datos disponobles.")

                elif SECCION == "5":
                    E.Lines("Número de veces que se repite un dato.")
                    while RESPUESTA < 30:
                        nombre = input("Dato a buscar: ")
                        print()
                        C.Count(GENERAL, nombre, test="NO")
                        print()
                        RESPUESTA = E.Change(RESPUESTA)
                        if RESPUESTA < 30:
                            print()
                    E.Lines("Número de veces que se repite un dato.")

            E.Lines("Bloque 1.")

        elif BLOQUE == "2":
            E.Lines("Bloque 2.")
            while RESPUESTA < 35:
                Blocks.Read_Text(C.Fila["Bloque2_inicio"], C.Fila["Bloque2_final"])
                # SECCION = str(input("Introduzca lo que quiere hacer: "))
                RESPUESTA = 37
            E.Lines("Bloque 2.")

        elif BLOQUE == "3":
            E.Lines("Bloque 3.")
            while RESPUESTA < 35:
                Blocks.Read_Text(C.Fila["Bloque3_inicio"], C.Fila["Bloque3_final"])
                # SECCION = str(input("Introduzca lo que quiere hacer: "))
                RESPUESTA = 37
            E.Lines("Bloque 3.")

        elif BLOQUE == "4":
            E.Lines("Bloque 4")
            while RESPUESTA < 35:
                Blocks.Read_Text(C.Fila["Bloque4_inicio"], C.Fila["Bloque4_final"])
                # SECCION = str(input("Introduzca lo que quiere hacer: "))
                RESPUESTA = 37
            E.Lines("Bloque 4")

        elif BLOQUE == "5":
            E.Lines("Otros.")
            while RESPUESTA < 35:
                Blocks.Read_Text(C.Fila["Otros_inicio"], C.Fila["Otros_final"])
                SECCION = str(E.Limit("Introduzca lo que quiere hacer: ", 6, "negativo"))
                RESPUESTA = 25

                if SECCION == "1":
                    E.Lines("Info.")
                    while RESPUESTA < 30:
                        Info.Read_Text(0, Limite_Info)
                        RESPUESTA = 32
                    E.Lines("Info.")

                elif SECCION == "2":
                    E.Lines("Gráfica.")
                    while RESPUESTA < 30:
                        Columns.Read_Text(0, 4)
                        print()
                        columna = C.Check_Column("Intoduzca 'deaths' o 'cases': ")
                        print()
                        State.Read_Text(0, Limite_State)
                        print()
                        estado = E.Check_State(GENERAL)
                        print()
                        C.Graph_State(GENERAL, estado, columna)
                        RESPUESTA = E.Change(RESPUESTA)
                        if RESPUESTA < 30:
                            print()
                    E.Lines("Gráfica.")

                elif SECCION == "3":
                    E.Lines("Diagrama de barras.")
                    while RESPUESTA < 30:
                        respuesta = E.Check_Yes_NO("¿Todos los estados? ")
                        print()
                        Columns.Read_Text(0, 4)
                        print()
                        columna = C.Check_Column("Intoduzca 'deaths' o 'cases': ")
                        print()
                        Month.Read_Text(0, Limite_Month)
                        print()
                        mes, día = E.Check_Date(GENERAL)
                        print()
                        State.Read_Text(0, Limite_State)
                        print()
                        C.Barchart_Day(GENERAL, mes, día, respuesta, columna)
                        RESPUESTA = E.Change(RESPUESTA)
                        if RESPUESTA < 30:
                            print()
                    E.Lines("Diagrama de Barras.")

                elif SECCION == "4":
                    E.Lines("Porcentajes.")
                    while RESPUESTA < 30:
                        respuesta = E.Check_Yes_NO("¿Todos los estados? ")
                        print()
                        Month.Read_Text(0, Limite_Month)
                        print()
                        mes, día = E.Check_Date(GENERAL)
                        print()
                        Columns.Read_Text(0, 4)
                        print()
                        columna = C.Check_Column("Intoduzca 'deaths' o 'cases': ")
                        print()
                        C.Percentage_Day(GENERAL, mes, día, columna, respuesta, test="NO")
                        RESPUESTA = E.Change(RESPUESTA)
                        if RESPUESTA < 30:
                            print()
                    E.Lines("Porcentajes")

                elif SECCION == "5":
                    E.Lines("Mapa.")
                    while RESPUESTA < 30:
                        Month.Read_Text(0, Limite_Month)
                        print()
                        mes, día = E.Check_Date(GENERAL)
                        print()
                        respuesta = E.Check_Yes_NO("¿Todos los casos? ")
                        print()
                        modificada = C.See_Date(GENERAL, mes, día, respuesta)
                        C.Generate_Map(modificada, respuesta)
                        RESPUESTA = E.Change(RESPUESTA)
                        if RESPUESTA < 30:
                            print()
                    E.Lines("Mapas.")

            E.Lines("Otros")

Info.Borrow_Text
State.Borrow_Text
Month.Borrow_Text
Columns.Borrow_Text
Blocks.Borrow_Text

E.Slow("Covid_USA ha finalizado.")

