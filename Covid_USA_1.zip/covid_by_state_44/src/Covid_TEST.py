import csv
from Tool import Covid as C, Easy as E
import os
from Tool.Class import Text

'''
autor: Alejandro Santiago Félix

Archivo con pruebas para el proyecto de Fun_Prin (módulo que contiene las funciones más avanzadas, el resto de módulo son auxiliares de esa).

Para crear todo este trabajo he intentado seguir las reglas del PEP-8 (la que menos he seguido ha sido E50 line too long).
'''


################################################################
#  Funciones auxiliares creadas para que funione 'ESTE MÓDULO'.
################################################################
def Create(mensaje,canal, final=0):
    """
    Crea ficheros que serán al instante eliminados.
    """
    archivo = Text(mensaje, canal)
    archivo.Create_Text
    if final == 0:
        archivo.Read_Text(1, C.Len_Text(f"{archivo}.txt"))
    elif final != 0:
        archivo.Read_Text(0, final)
    archivo.Borrow_Text


def Read_Excel():
    """
    Permite obtener la información que necesitamos para más adelante.
    """
    with open('../data/covid_by_state.csv', encoding='utf-8') as f:
        lector = csv.reader(f)
        next(lector)
        GENERAL = [(date, state, int(fips), int(cases), int(deaths))
                   for date, state, fips, cases, deaths in lector]
    return GENERAL


################################################################
# Funciones creadas para mostrar fácilmente las funciones del módulo Fun_Prin.
################################################################
def test_When_Up(info: list):
    """
    Prueba para obtener cuando un estado ha superado una cierta cifra de casos.
    """
    E.Lines("Busqueda de casos o muertes en un país.")  # Permite tener una cierta idea de que va el programa.
    Create(C.m_State, canal=7)  # Para poder leer información necesaria para poder elegir el estado correctamente.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    estado = E.Check_State(info)  # Para poder meter un estado (no funcionará con otra cosa).
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    Create(C.m_Columns, canal=11, final=5)  # Muestra cuales son las posibles columnas a estudiar.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    columna = C.Check_Column("Intoduzca 'deaths' o 'cases': ")  # Para poder elegir una de las columna.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    if columna == "deaths":
        casos = E.Check_Number("Introduzca el número de fallecidos: ", int) # Permite meter el número de muertes a estudiar.
    elif columna == "cases":
        casos = E.Check_Number("Introduzca el número de casos:", int)  # Para meter una cifra de casos.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    número, Lista1 = C.When_Up(info, estado, casos, columna)
    while True:
        if número == 3:
            print(f"En el estado de {Lista1[0][1]} fue superado el número de casos de {casos}")
            print(f"casos en la fecha {Lista1[0][0]}, habiendo hasta ese momento ")
            print(f"{Lista1[0][número+1]} fallecidos y {Lista1[0][número]} casos.")
            break
        elif número == 4:
            print(f"En el estado de {Lista1[0][1]} fue superado el número de casos de {casos}")
            print(f"muertes en la fecha {Lista1[0][0]}, habiendo hasta ese momento ")
            print(f"{Lista1[0][número]} fallecidos y {Lista1[0][número-1]} casos.")
            break
    E.Lines("Busqueda de casos o muertes en un país.")  # Para poder saber cuando termina el programa.


def test_See_State(info: list):
    """
    Prueba para obterner información fácil de comprender de un estado, si sale negativo al poner 
    respuesta = "NO es debido a la recuperación o fallecimiento (soreprendentemente 2020-09-09 en New York resucitó 
    una persona, lo comprobé con la base de datos que se crea con la función Create_DB_Covid) de algún
    paciente.
    """
    E.Lines("Estudio de un estado.")  # Permite tener una cierta idea de que va el programa.
    Create(C.m_State, canal=7)  # Para poder leer información necesaria para poder elegir el estado correctamente.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    estado = E.Check_State(info)  # Para poder meter un estado (no funcionará con otra cosa).
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    respuesta = E.Check_Yes_NO("¿Todos los casos? ")  # Para poder ver el creciemnto de casos o solo los de cada día.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    info = C.See_State(info, estado)
    print(f"En el estado {info[0][1]}:\n")  # Para poder comprenderlo posteriormente más fácilmete.
    for i in range(0, len(info)):
        if i == 0 or respuesta == "SI":
            print(f"En la fecha {info[i][0]} tuvo {info[i][3]} casos y {info[i][4]} muertes.\n")
        else:
            print(f"En la fecha {info[i][0]} tuvo {int(info[i][3])-int(info[i-1][3])} casos y {int(info[i][4])-int(info[i-1][4])} muertes.\n")
    E.Lines("Estudio de un estado.")  # Para poder saber cuando termina el programa.

def test_See_Date(info: list):
    """ 
    Permite obtener información acerca de los estados en una fecha en concreto, menciono lo mismo que en See_State,
    puede salir datos negativos por la recuperación de un paciente o un fallo en la lista de muertos si no se pueden utililizar 
    Create_DB_Covid para comprobarlo.
    """
    E.Lines("Estufio de un día")
    Create(C.m_Month, canal=9)
    print()
    mes, día = E.Check_Date(info)
    print()
    respuesta = E.Check_Yes_NO("¿Todos los casos? ")
    print()
    Lista = C.See_Date(info, mes, día, respuesta= respuesta)
    modificada = C.Order_States(Lista)
    if respuesta == "SI":  # Si  respuesta = "SI", realizará un estudio de todos los casos hasta el momento.
        print(f"En la fecha {modificada[1][0]}:\n") # Para poder comprenderlo posteriormente más fácilmete.
    elif respuesta == "NO":  # Si  respuesta = "NO", realizará un estudio de los casos de ese día.
        print(f"En la fecha {modificada[0][0]}:\n") # Para poder comprenderlo posteriormente más fácilmete.
    Lista1 = []
    for i in range(0, len(modificada)):
        if respuesta == "SI":
            print(f"En {modificada[i][1]} con un código o fip de {modificada[i][2]}")
            print(f"tuvo {int(modificada[i][3])} casos y {int(modificada[i][4])} muertes.\n")
        condicion = modificada[i][1] in Lista1  # Impongo que únicamente estudie aquellos valores que en la columna 'date' coinciden con la fecha introducida.
        if respuesta == "NO" and condicion:
            print(f"En {modificada[i][1]} con un código o fip de {modificada[i][2]}")
            print(f"tuvo {int(modificada[i][3])-int(modificada[i-1][3])} casos y {int(modificada[i][4])-int(modificada[i-1][4])} muertes.\n")
        Lista1.append(modificada[i][1])
    del(Lista1)

def test_Show_Something(info: list):
    """
    Prueba para obtener información de cualquier columna ('date', 'state', 'fips', 'cases' y 'deaths').
    """
    E.Lines("Muestra los valores de una columna.")  # Permite tener una cierta idea de que va el programa.
    Create(C.m_Columns, canal=11)  # Muestra las columnas que tiene el excel.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    columna = C.Check_Column("Introduzca la columna de la que quiere saber algo: ") # Para poder elegir una de las columna.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    respuesta = E.Check_Yes_NO("¿Quiere todos los valores? ")  # Permite elegir una secuencia de valores al decir no.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    cadena = C.Get_Info(info, columna, respuesta)
    if columna == "date":
        return print(f"Las fechas en este documento son:\n{cadena}")
    elif columna == "state":
        return print(f"Los estados en este documento son:\n{cadena}")
    elif columna == "fips":
        return print(f"Los fips en este documento son:\n{cadena}")
    elif columna == "cases":
        return print(f"Valores de casos en el documento:\n{cadena}")
    elif columna == "deaths":
        return print(f"Valores de muertes en el documento:\n{cadena}")
    E.Lines("Muestra los valores de una columna.")  # Para poder saber cuando termina el programa.


def test_Count(info: list):

    """Permite sasber el número de veces que se repite un dato."""

    E.Lines("Número de veces que se repite un dato.")  # Permite tener una cierta idea de que va el programa.
    nombre = input("Dato a buscar: ")  # Introducir que se quiere buscar (no es necesario un Check)
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    número = C.Count(info, nombre)
    # Parte en la que se pretende mostrar la información en pantalla de fprma elegante.
    if número == False:
        print(f"No se ha encontrado {nombre} en la lista.")
    else:
        print(f"El número de veces que se ha encontrado {nombre} es de {número} veces.")
    E.Lines("Número de veces que se repite un dato.")  # Para poder saber cuando termina el programa.


def test_Graph_State(info: list):
    """
    Dibuja una gráfica sobre la evolución del coronavirus en un estado a lo largo del tiempo.
    """
    E.Lines("Gráfica.")  # Permite tener una cierta idea de que va el programa.
    Create(C.m_Columns, canal=11, final=5)  # Muestra cuales son las posibles columnas a estudiar.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    columna = C.Check_Column("Intoduzca 'deaths' o 'cases': ")  # Para poder elegir una de las columna.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    Create(C.m_State, canal=7)  # Para poder leer información necesaria para poder elegir el estado correctamente.
    estado = E.Check_State(info)  # Para poder meter un estado (no funcionará con otra cosa).
    C.Graph_State(info, estado, columna)
    E.Lines("Gráfica.")  # Para poder saber cuando termina el programa.


def test_Barchart_Day(info: list):
    """
    Dibuja un diagrama de barras en el que se comparan en un día diferentes estados.
    """
    E.Lines("Diagrama de barras.")  # Permite tener una cierta idea de que va el programa.
    respuesta = E.Check_Yes_NO("¿Todos los estados? ")  # Permite que posteriormente se inserte uno a uno el estado.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    Create(C.m_Columns, canal=11, final=5)  # Muestra cuales son las posibles columnas a estudiar.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    columna = C.Check_Column("Intoduzca 'deaths' o 'cases': ") #
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    Create(C.m_Month, canal=9)  # Para poder leer información necesaria para poder elegir una fecha (tiene que ser con número empezando con cero si está entre 0 o 9) correctamente.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    mes, día = E.Check_Date(info)  # Para poder darle una fecha que sea correcta y no de error.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    Create(C.m_State, canal=7)  # Para poder leer información necesaria para poder elegir el estado correctamente.
    C.Barchart_Day(info, mes, día, respuesta, columna)
    E.Lines("Diagrama de barras.")  # Para poder saber cuando termina el programa.


def test_Percentage_Day(info: list):
    """
    Permite mostrar de una forma clara la información de los porcentajes.
    """
    E.Lines("Porcentajes.")  # Permite tener una cierta idea de que va el programa.
    respuesta = E.Check_Yes_NO("¿Todos los estados? ")  # Permite que posteriormente se inserte uno a uno el estado.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    Create(C.m_Month, canal=9)  # Para poder leer información necesaria para poder elegir una fecha (tiene que ser con número empezando con cero si está entre 0 o 9) correctamente.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    mes, día = E.Check_Date(info)  # Para poder darle una fecha que sea correcta y no de error.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    Create(C.m_Columns, canal=11, final=5)  # Muestra cuales son las posibles columnas a estudiar.
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    columna = C.Check_Column("Introduzca 'deaths' o 'cases': ")  # Para poder elegir la columna (tengo que crear una función Check).
    print()  # Hace que se vea más claro la información relevante al insertar un espaciado.
    modificada = C.Percentage_Day(info, mes, día, columna, respuesta)
    for i in range(0, len(modificada)):
        if columna == "cases":
            print(f"El porcentaje de casos en {modificada[i][0]} es {modificada[i][1]} %.")
        elif columna == "deaths":
            print(f"El porcentaje de muertes en {modificada[i][0]} es {modificada[i][1]} %.")
    E.Lines("Porcentajes.")  # Para poder saber cuando termina el programa.

def test_Generate_Map(info: list):
    E.Lines("Mapa.")
    Create(C.m_Month, canal=9)
    print()
    mes, día = E.Check_Date(info)
    print()
    respuesta = E.Check_Yes_NO("¿Todos los casos? ")
    print()
    modificada = C.See_Date(info, mes, día, respuesta)
    C.Generate_Map(modificada, respuesta)
    E.Lines("Mapas.")

################################################################
# Programa principal.
################################################################
if __name__ == '__main__':
    fichero = Read_Excel()
    # test_When_Up(fichero)
    # test_See_State(fichero)
    # test_See_Date(fichero)
    # test_Show_Something(fichero)
    # test_Count(fichero)
    # test_Graph_State(fichero)
    # test_Barchart_Day(fichero)
    # test_Percentage_Day(fichero)
    # test_Generate_Map(fichero)
