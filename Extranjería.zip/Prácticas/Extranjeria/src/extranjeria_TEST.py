from extranjeria import *

################################################
#Programa principal
################################################



def mostrar_numerado(coleccion, n=None):
    i=0
    if n == None:
        n = len(coleccion)
    for p in coleccion[:n]:
        i=i+1
        print (i, p) 
        
def mostrar_diccionario(diccionario, n=None):
    if n == None:
        n = len(diccionario)
    for item in list(diccionario.items())[:n]:
        print(item)
        
################################################

def test_lee_datos_extranjeros(datos_extranjeros):
    print(f"Se han leído {len(datos_extranjeros)} registros")
    mostrar_numerado(datos_extranjeros, 5)

def test_numero_nacionalidades_distintas(datos_extranjeros):
    numero_nacionalidades = numero_nacionalidades_distintas(datos_extranjeros)
    print(numero_nacionalidades)
    print(f"Hay {numero_nacionalidades} nacionalidades distintas.")

def test_secciones_distritos_con_extranjeros_nacionalidad(datos_extranjeros):
    paises_l = ["COMORES", "NUEVA ZELANDA"]
    paises_s = {"COMORES", "NUEVA ZELANDA"}
    paises_t = ("COMORES", "NUEVA ZELANDA")
    secciones_distritos = secciones_distritos_con_extranjeros_nacionalidades(datos_extranjeros, paises_s)
    print(f"Se han encontrado {len(secciones_distritos)} secciones en distritos extranjeros cuyas secciones son comunes a {paises_l[1]}")

def test_total_extranjeros_por_país(datos_extranjeros):
    dicc_extranjeros_pais = total_extranjeros_por_pais(datos_extranjeros)
    print(f"Hay {len(dicc_extranjeros_pais)} países distintos.")
    mostrar_diccionario(dicc_extranjeros_pais)

def test_top_extranjería(datos_extranjeros):
    top_paises = top_n_extranjeria(datos_extranjeros, 5)
    print("Paises con mayor población extranjera:")
    for i in range(0, len(top_paises)):
        print(f"En el puesto {i+1}, {top_paises[i][0]} con {top_paises[i][1]} habitantes.")

def test_barrio_mas_multicultural(datos_extranjeros):
    barrio = barrio_mas_multicultural(datos_extranjeros)
    print(f"{barrio} es el barrio más multiculatural.")
    
def test_mayor_extranjeros(datos_extranjeros):
    tipo = "Mujeres"
    barrio = barrio_con_mas_extranjeros(datos_extranjeros, tipo)
    if tipo != None:
        print(f"{barrio} es el barrio con mayor poblacion de {tipo}.")
    else:
        print(f"{barrio} es el barrio con mayor poblacion de hombres y mujeres.")

def test_país_mas_representado_por_distritos(datos_extranjeros):
    paises_distritos = pais_mas_representado_por_distrito(datos_extranjeros)
    print("País más representado por cada distrito.")
    for distrito, pais in paises_distritos.items():
        print(f"distrtito {distrito}: pais {pais}") 

if __name__ == "__main__":
    ruta_fichero = "../data/extranjerosSevilla.csv"
    fichero = lee_datos_extranjeros(ruta_fichero)
    test_lee_datos_extranjeros(fichero)
    test_numero_nacionalidades_distintas(fichero)
    test_secciones_distritos_con_extranjeros_nacionalidad(fichero)
    test_total_extranjeros_por_país(fichero)
    test_top_extranjería(fichero)
    test_barrio_mas_multicultural(fichero)
    test_mayor_extranjeros(fichero)
    test_país_mas_representado_por_distritos(fichero)