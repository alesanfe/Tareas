from typing import List, Set, Tuple
from collections import namedtuple
import csv
import operator
import matplotlib.pyplot as plt

FrecuenciaNombre = namedtuple("FrecuenciaNombre", "año, nombre, frecuencia, genero")


def leer_frecuencias_nombres(fichero: str) -> List[FrecuenciaNombre]:
    
    with open(fichero, encoding = "utf_8") as f:
        lector = csv.reader(f)
        next(lector)
        registros = [FrecuenciaNombre(int(año), nombre, int(frecuencia), genero) for año, nombre, frecuencia, genero in lector]
    return registros


def filtrar_por_género(registros: List[FrecuenciaNombre], genero: str) -> List[FrecuenciaNombre]:
    
    lista_filtrada = [r for r in registros if r.genero==genero]
    return lista_filtrada


def calcular_nombres(registros: List[FrecuenciaNombre], genero: str=None) -> Set[str]: 
    
    if genero != None:
        registros = filtrar_por_género(registros, genero)
    return set(r.nombre for r in registros)


def calcular_top_nombre_de_año(registros: List[FrecuenciaNombre], año: int, límite: int = 10, genero:str = None) -> Tuple[str, int]:
    
    if genero != None:
        registros = filtrar_por_género(registros, genero)
    resultados = [(r.nombre, r.frecuencia) for r in registros if r.año == año]
    resultados.sort(key=lambda x: x[1], reverse = True)


def calcular_nombres_ambos_generos(registros: List[FrecuenciaNombre]) -> Set[str]:
    
    hombres = filtrar_por_género(registros, "Hombre")
    mujeres = filtrar_por_género(registros, "Mujer")
    nombre_hombres = [h.nombre for h in hombres]
    nombre_mujeres = [m.nombre for m in mujeres] 
    ambos = {r.nombre for r in registros if r.nombre in nombre_hombres and r.nombre in nombre_mujeres}
    return ambos


def calcular_nombres_compuestos(registros: List[FrecuenciaNombre], género: str=None) -> Set[str]:
    
    if género != None:
        registros = filtrar_por_género(registros, género)
    resultados = {r.nombre for r in registros if len(r.nombre.split())>=2}
    return resultados

       
def calcular_nombre_mas_frecuente_por_año(registros: List[FrecuenciaNombre], género: str=None) -> List[Tuple[int, str, int]]:
    
    if género != None:
        registros = filtrar_por_género(registros, género)
    año, lista_anual, inicio, resultado =0, [], True, []
    for r in registros:
        if r.año != año:
            año = r.año
            if inicio is False:
                max_año= max(lista_anual, key = operator.itemgetter(2))
                resultado.append(max_año)
                lista_anual.clear()
            inicio = False
        lista_anual.append((r.año, r.nombre, r.frecuencia)) 
    return resultado

   
def calcular_frecuencia_por_año(registros: List[FrecuenciaNombre], nombre: str) -> List[Tuple[int, int]]:
    
    año, lista_anual, inicio, resultado = 0, [], True, [] 
    for r in registros:
        if nombre == r.nombre:
            if r.año != año:
                if inicio is False:
                    resultado.append((año, frecuencia))
                año, frecuencia, inicio = r.año, 0, False
            frecuencia += r.frecuencia
    resultado.append((año, frecuencia))
    return resultado


def mostrar_evolución_por_año(registros: List[FrecuenciaNombre], nombre: str):
    
    nombre_años = calcular_frecuencia_por_año(registros, nombre)
    años = [año[0] for año in nombre_años]
    frecuencias = [año[1] for año in nombre_años]
    # año, frecuencia = [], []
    # for año in nombre_año:
    #    años.append(mostrar_años[0])
    #    frecuencia.append(mostrar_años[1])
    plt.plot(años, frecuencias)
    plt.grid()
    plt.ylabel("Frecuencia.")
    plt.xlabel("Años.")
    plt.title(f"Evolución del nombre '{nombre}'")
    plt.show()


def calcular_frecuencia_acumulada(registros: List[FrecuenciaNombre], nombre: str) -> int:
    
    nombre_años, frecuencia = calcular_frecuencia_por_año(registros, nombre), 0
    for año in nombre_años:
        frecuencia += año[1]
    return frecuencia


def calcular_fecuencia_por_nombre(registros: List[FrecuenciaNombre]):
    
    nombres = sorted(list({r.nombre for r in registros}))
    frecuencia_nombres = {n: calcular_frecuencia_acumulada(registros, n) for n in nombres}
    return frecuencia_nombres
        

def mostrar_frecuencias_nombres(registros: List[FrecuenciaNombre], límite):
    
    frecuencia_nombres = calcular_fecuencia_por_nombre(registros)
    frecuencia_nombre_ord = dict(sorted(frecuencia_nombres.items(), key=operator.itemgetter(1), reverse = True))
    nombres, frecuencias = [], []
    for n in frecuencia_nombre_ord.keys():
        if len(nombres) < límite:
            nombres.append(n)
    for f in frecuencia_nombre_ord.values():
        if len(frecuencias) < límite:
            frecuencias.append(f)
    plt.figure(figsize=(14,8))
    plt.bar(nombres, frecuencias)
    plt.grid()
    plt.ylabel("Frecuencia.")
    plt.xlabel("Nombres.")
    
    plt.title(f"Frecuencia de los {límite} nombres más comunes.")
    plt.show()

    