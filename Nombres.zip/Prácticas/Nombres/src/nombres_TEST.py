from nombres import *


################################################################
#  Funciones auxiliares
################################################################
def mostrar_coleccion(coleccion, n = 3):
    if n > len(coleccion):
        n = len(coleccion)
    for i,p in enumerate(coleccion[:n], start = 1):
        print(i, p)

def mostrar_diccionario(diccionario, n=None):
    if n == None:
        n = len(diccionario)
    for item in list(diccionario.items())[:n]:
        print(item)
################################################################
#  Funciones de test
################################################################
def test_leer_frecuencias_nombres():    # 1
    print(f"Se han leído {len(registros)} registros de nombres.")
    mostrar_coleccion(registros, 5)


def test_filtrar_por_género():  # 2
    print("TEST de filtrar por género.")
    print(f"    - Número de registros para 'Hombre' : {len(filtrar_por_género(registros, 'Hombre'))}")
    print(f"    - Número de registros para 'Mujer' : {len(filtrar_por_género(registros, 'Mujer'))}")

    n = 7
    genero = 'Mujer'
    print(f"Primeros {n} registros para {genero}:")
    lista_filtrada = filtrar_por_género(registros, genero)
    mostrar_coleccion(lista_filtrada, n)
    
    genero = 'Hombre'
    print(f"Primeros {n} registros para {genero}:")
    lista_filtrada = filtrar_por_género(registros, genero)
    mostrar_coleccion(lista_filtrada, n)

    
def test_calcular_nombres():    # 3
    print("TEST de 'calcular nombres'")
    print(f"    - Número de nombres para ambos géneros: {len(calcular_nombres(registros))}")
    print(f"    - Número de nombres de mujeres: {len(calcular_nombres(registros, 'Mujer'))}")
    print(f"    - Número de nombres para hombres: {len(calcular_nombres(registros, 'Hombre'))}")

    genero = None
    conjunto_nombres = calcular_nombres(registros, genero)
    print(f"Se han obtenido {len(conjunto_nombres)} para ambos géneros.")
    mostrar_coleccion(list(conjunto_nombres), 2)
    
    genero = 'Hombre'
    conjunto_nombres = calcular_nombres(registros, genero)
    print(f"Se han obtenido {len(conjunto_nombres)} de hombres.")
    mostrar_coleccion(list(conjunto_nombres), 2)
    
    genero = 'Mujer'
    conjunto_nombres = calcular_nombres(registros, genero)
    print(f"Se han obtenido {len(conjunto_nombres)} de mujeres.")
    mostrar_coleccion(list(conjunto_nombres), 2)


def test_calcular_top_nombres_de_año(): # 4
    top_nombre_mujeres = calcular_top_nombre_de_año(registros, 2002, 20, 'Mujer')
    print(f"Top de nombre de mujeres: {top_nombre_mujeres}.")
    
def test_calcular_nombres_ambos_generos():  # 5
    
    ambos_géneros = calcular_nombres_ambos_generos(registros)
    print(f"Se han obtenido {len(ambos_géneros)} que coinciden en ambos géneros.")
    mostrar_coleccion(list(ambos_géneros), 2)

def test_calcular_nombres_compuestos(): # 6
    genero = None
    nombres_compuestos = calcular_nombres_compuestos(registros, genero)
    print(f"Se han obtenido {len(nombres_compuestos)} nombres compuestos para ambos géneros.")
    mostrar_coleccion(list(nombres_compuestos), 2)
    
    genero = "Mujer"
    nombres_compuestos = calcular_nombres_compuestos(registros, genero)
    print(f"Se han obtenido {len(nombres_compuestos)} nombres compuestos para mujeres.")
    mostrar_coleccion(list(nombres_compuestos), 2)

    genero = "Hombre"
    nombres_compuestos = calcular_nombres_compuestos(registros, genero)
    print(f"Se han obtenido {len(nombres_compuestos)} nombres compuestos para mujeres.")
    mostrar_coleccion(list(nombres_compuestos), 2)

def test_calcular_nombre_mas_frecuente_por_año(): # 7
    genero = None
    más_frecuente = calcular_nombre_mas_frecuente_por_año(registros, genero)
    print(f"Se han leído {len(más_frecuente)} años.")
    mostrar_coleccion(list(más_frecuente), 2)

    genero = "Hombre"
    más_frecuente = calcular_nombre_mas_frecuente_por_año(registros, genero)
    print(f"Se han leído {len(más_frecuente)} años.")
    mostrar_coleccion(list(más_frecuente), 2)
    
    genero = "Mujer"
    más_frecuente = calcular_nombre_mas_frecuente_por_año(registros, genero)
    print(f"Se han leído {len(más_frecuente)} años.")
    mostrar_coleccion(list(más_frecuente), 2)

def test_calcular_frecuencia_por_año():
    nombre = "JULIETA"
    frecuencia = calcular_frecuencia_por_año(registros, nombre)
    print(f"Se han leído {len(frecuencia)} años.")
    mostrar_coleccion(frecuencia, 2)
    
    nombre = "ABRIL"
    frecuencia = calcular_frecuencia_por_año(registros, nombre)
    print(f"Se han leído {len(frecuencia)} años.")
    mostrar_coleccion(frecuencia, 2)

def test_mostrar_evolución_por_año():
    nombre = "LUCIA"
    mostrar_evolución_por_año(registros, nombre)

def test_calcular_frecuencia_acumulada():
    nombre = "JULIETA"
    frecuencia_total = calcular_frecuencia_acumulada(registros, nombre)
    print(f"La frecuencia acumulada a lo largo de los \naños del nombre {nombre} es de {frecuencia_total}.")
    
def test_calcular_frecuencia_por_nombre():
    
    frecuencia_nombres= calcular_fecuencia_por_nombre(registros)
    print(frecuencia_nombres)
    print(f"Se han leído {len(frecuencia_nombres)} nombres.")
    mostrar_diccionario(frecuencia_nombres, 2)
    
def test_mostrar_frecuencias_nombres():
    
    límite = 10
    mostrar_frecuencias_nombres(registros, límite)

if __name__ == "__main__":
    ruta_fichero = "../data/frecuencias_nombres.csv"
    registros = leer_frecuencias_nombres(ruta_fichero)

    # test_leer_frecuencias_nombres()
    # test_filtrar_por_género()
    # test_calcular_nombres()
    # test_calcular_top_nombres_de_año()
    # test_calcular_nombres_ambos_generos()
    # test_calcular_nombres_compuestos()
    # test_calcular_nombre_mas_frecuente_por_año()
    # test_calcular_frecuencia_por_año()
    # test_mostrar_evolución_por_año()
    # test_calcular_frecuencia_acumulada()
    # test_calcular_frecuencia_por_nombre()
    # test_mostrar_frecuencias_nombres()