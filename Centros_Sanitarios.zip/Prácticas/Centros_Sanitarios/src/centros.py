import csv
from collections import namedtuple
from selectors import BaseSelector
from coordenadas import Coordenada, calcular_distancia,\
    calcular_media_coordenadas
from typing import List
from mapas import crea_mapa, crea_marcador


CentroSanitario = namedtuple('CentroSanitario', 'nombre, localidad, coordenada, estado, num_camas, acceso_minusvalidos, tiene_uci')

# ===============================================================================
# Funciones auxiliares
# ===============================================================================
def parse_bool(cadena: str) -> bool:
    if cadena == "true":
        resultado = True
    elif cadena == "false":
        resultado = False
    return resultado

# ===============================================================================
# Funciones principales
# ===============================================================================
def leer_centros(fichero: str) -> List[CentroSanitario]:
    with open(fichero, encoding="utf-8") as f:
        lector = csv.reader(f, delimiter=';')
        next(lector)
        centros = []
        for nombre, localidad, latitud, longitud, estado, num_camas, acceso_minusvalidos, tiene_uci in lector:
                coordenada = Coordenada(float(latitud), float(longitud))
                centro_sanitario = CentroSanitario(
                    nombre.strip(),
                    localidad.strip(),
                    coordenada,
                    estado.strip(),
                    int(num_camas),
                    parse_bool(acceso_minusvalidos.strip()),
                    parse_bool(tiene_uci.strip()))
                    #===========================================================
                    # eval(acceso_minusvalidos.strip().capitalize()),
                    # eval(tiene_uci.strip().capitalize())
                    #===========================================================
                centros.append(centro_sanitario)
        return centros


def calcular_camas_centros_accesibles(centros: List[CentroSanitario]):
    cantidad = 0
    for centro in centros:
        if centro.acceso_minusvalidos:
            cantidad += centro.num_camas
    return cantidad

def obtener_centros_sanitarios_cercanos_a(centros: List[CentroSanitario], umbral: float, punto: Coordenada):
    centros_cercanos = []
    # Alternativa 1.
    for centro in centros:
        if centro.tiene_uci:
            dist = calcular_distancia(centro.coordenada, punto)
            if dist <= umbral:
                centros_cercanos.append((centro.nombre,
                                         centro.localidad,
                                         centro.coordenada))
    return centros_cercanos


def generar_mapa(centros: list, fichero):
    centros_coordenadas = [coordenada for _, _, coordenada in centros]
    centro_mapa = calcular_media_coordenadas(centros_coordenadas)
    mapa = crea_mapa(centro_mapa.latitud, centro_mapa.longitud)
    for nombre, localidad, coordenada in centros:
        etiqueta = f"{nombre},({localidad})"
        marcador = crea_marcador(coordenada.latitud, coordenada.longitud, etiqueta)
        marcador.add_to(mapa)
    mapa.save(fichero)
