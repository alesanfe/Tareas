from coordenadas import *
from random import uniform


# =============================
def generar_coordenadas_aleatorias(n: int=1) -> List[Coordenada]:
    coordenadas = list()  # []
    for _ in range(n):
        lat, long = uniform(-90, 90), uniform(-180, 180)
        coordenadas.append(Coordenada(lat, long))
    return coordenadas
# =============================


def test_calcular_distancia():
    punto_1 = generar_coordenadas_aleatorias()[0]
    punto_2 = generar_coordenadas_aleatorias()[0]
    dist = calcular_distancia(punto_1, punto_2)
    print(f"La distancia entre el punto {punto_1} y el punto {punto_2} es de {dist}.")


def test_calcular_media_de_las_coordenadas():
    coordenadas = generar_coordenadas_aleatorias(10)
    media = calcular_media_coordenadas(coordenadas)
    print(f"La media de las coordenadas es {media}")


if __name__ == '__main__':
    test_calcular_distancia()
    test_calcular_media_de_las_coordenadas()