from centros import leer_centros, calcular_camas_centros_accesibles, obtener_centros_sanitarios_cercanos_a,\
    generar_mapa
from coordenadas import Coordenada

def mostrar_numerado(coleccion, n = None):
    if n is None or n > len(coleccion):
        n = len(coleccion)
    for i, p in enumerate(coleccion[:n], start=1):
        print (i, p)


def test_leer_centros(info):
    print(f"Se han leído {len(info)} centros.")
    mostrar_numerado(centros)

def test_calcular_total_camas_centros_accesibles(info):
    total_camas = calcular_camas_centros_accesibles(info)
    print(f"El número de camas {total_camas}")

def test_obtener_centros_sanitarios_cercanos_a(info):
    latitud = 36.1350167
    longitud = -5.843455923
    centros_cercanos = obtener_centros_sanitarios_cercanos_a(info, 10, Coordenada(latitud, longitud))
    print(f"Los centros sanitarios con UCI encontrados son: ")
    mostrar_numerado(centros_cercanos)
    ruta_mapa = "../out/mapa_centros_cercanos.html"
    generar_mapa(centros_cercanos, ruta_mapa)

if __name__ ==  "__main__":
    ruta_fichero = "../data/centrosSanitarios.csv"
    centros = leer_centros(ruta_fichero)
    # ===========================================================================
    # for c in centros:
    #     print(c)
    # ===========================================================================
    # test_leer_centros(centros)
    # test_calcular_total_camas_centros_accesibles(centros)
    test_obtener_centros_sanitarios_cercanos_a(centros)