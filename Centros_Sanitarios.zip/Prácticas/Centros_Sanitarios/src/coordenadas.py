from collections import namedtuple
from math import sqrt
from statistics import mean
from typing import List

Coordenada = namedtuple('Coordenada', 'latitud, longitud')

def calcular_distancia(coordenada_1: Coordenada, coordenada2: Coordenada) -> float:
    """
    Calcular la distancia euclídea netre dos puntos.

    ENTRADA:
            Coordenada(float, float) representa a el punto 1 mediante su latitud y su longitud.
            Coordenada(float, float) representa a el punto 2 mediante su latitud y su longitud.

    SALIDA:
            Distancia Euclídea entre la coordenada 1 y la coordenada 2.
    """
    diff_lat, diff_long = (coordenada2.latitud - coordenada_1.latitud), (coordenada2.longitud - coordenada_1.longitud)
    dist = sqrt(diff_lat**2 + diff_long**2)
    return dist

def calcular_media_coordenadas(coordenadas_centros: List[Coordenada]) -> Coordenada:
    """
    Calcula un punto cuta latitud es la media de las latitudes de los centros que se pasan
    como parámetro y cuya longitud es la media de las longitudes de los centros que se 
    pasan como parámetro.

    ENTRADA:
            coordenadas_centros: lista de tuplas (latitud, longitud) -> Coordenada(float,float)
    SALIDA:
            tupla(latitud, longitud) -> Coordenada(float, float)
    """
    #===========================================================================
    # # Alternativa 1
    # media_latitud = (c.latitud for c in coordenadas_centros)/len(coordenadas_centros)
    # media_longitud = (c.longitud for c in coordenadas_centros)/len(coordenadas_centros)
    #
    # # Alternativa 2
    # media_latitud = sum(latitud for latitud, _ in coordenadas_centros)/len(coordenadas_centros)
    # media_longitud = sum(longitud for _, longitud in coordenadas_centros)/len(coordenadas_centros)
    #===========================================================================

    # Alternativa
    media_latitud = mean(c.latitud for c in coordenadas_centros)
    media_longitud = mean(c.longitud for c in coordenadas_centros)
    return Coordenada(media_latitud, media_longitud)